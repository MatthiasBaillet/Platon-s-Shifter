# -*- coding: utf-8 -*-
import sys

# Lire Game.js
with open('Game.js', 'r', encoding='utf-8', errors='ignore') as f:
    contenu = f.read()

# Lignes � ajouter � la fin
ajout = """


// ===== NETTOYAGE FUITES MEMOIRE =====
window.removeEventListener('DOMContentLoaded', init);
window.removeEventListener('mousedown', handleMouseDown);
window.removeEventListener('mousemove', handleMouseMove);
window.removeEventListener('mouseup', handleMouseUp);
window.removeEventListener('keydown', handleKeydown);
window.removeEventListener('keyup', handleKeyup);
// =====================================
"""

# �crire le nouveau fichier
with open('Game_corrige.js', 'w', encoding='utf-8') as f:
    f.write(contenu + ajout)

print("? Nettoyage termin� !")
print("Renommez Game_corrige.js en Game.js")