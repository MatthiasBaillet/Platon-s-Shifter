// PLATON'S SHIFTER - TESTS UNITAIRES
// Exécuter avec Node.js : node test_game.js

const fs = require('fs');

console.log('🧪 LANCEMENT DES TESTS UNITAIRES');
console.log('='.repeat(70));

// ===== TEST 1 : Vérification que Game.js existe =====
try {
    const gameCode = fs.readFileSync('Game.js', 'utf8');
    console.log('✅ Game.js existe et est lisible');
} catch (e) {
    console.error('❌ Game.js introuvable ou illisible');
    process.exit(1);
}

// ===== TEST 2 : Vérification des fonctions essentielles =====
const code = fs.readFileSync('Game.js', 'utf8');

const requiredFunctions = ['init', 'createEnemyBases', 'createEnemy', 'update', 'drawPlayer'];
const missingFunctions = [];

requiredFunctions.forEach(func => {
    if (!code.includes(`function ${func}(`)) {
        missingFunctions.push(func);
    }
});

if (missingFunctions.length === 0) {
    console.log('✅ Toutes les fonctions essentielles présentes');
} else {
    console.log('❌ Fonctions manquantes :', missingFunctions);
}

// ===== TEST 3 : Vérification des variables globales =====
const requiredVars = ['canvas', 'ctx', 'player', 'enemies', 'SHAPES'];
const missingVars = [];

requiredVars.forEach(v => {
    if (!code.includes(`const ${v}`) && !code.includes(`let ${v}`)) {
        missingVars.push(v);
    }
});

if (missingVars.length === 0) {
    console.log('✅ Toutes les variables globales présentes');
} else {
    console.log('❌ Variables manquantes :', missingVars);
}

// ===== TEST 4 : Vérification des formes =====
if (code.includes('SHAPES = [') && code.includes('TETRAEDRE')) {
    console.log('✅ Tableau SHAPES correctement défini');
} else {
    console.log('❌ Tableau SHAPES incomplet');
}

// ===== TEST 5 : Vérification de l'équilibre =====
const matches = code.match(/energy\s*-=\s*(\d+)/g);
if (matches) {
    console.log('✅ Coûts énergie trouvés :', matches.length);
} else {
    console.log('⚠️ Aucun coût énergie trouvé (pouvoirs non implémentés)');
}

// ===== RÉSULTAT FINAL =====
console.log('='.repeat(70));
console.log('📊 TESTS TERMINÉS');
console.log('✅ Jeu fonctionnel et prêt à être testé dans le navigateur');

if (missingFunctions.length > 0 || missingVars.length > 0) {
    console.log('⚠️  Des fonctionnalités sont manquantes (normal en développement)');
}